<section class="subscribe_never_miss">
  <div class="container">
    <div class="inner_content text-center">
      <h2 class="section_heading section_heading_medium default_color">
        NEVER MISS OUT!
      </h2>
      <p class="sub_heading">
        Subscribe for upcoming freebies, offers, and best deals
      </p>
      <form action="">
        <input type="email" name="" id="subscription-email" placeholder="Email" required />
        <input class="btn_primary _btn submit-subscription" type="button" value="SUBSCRIBE" />
      </form>
    </div>
  </div>
</section>
