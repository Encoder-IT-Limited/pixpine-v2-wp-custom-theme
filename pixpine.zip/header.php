<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- <title>Pixpine</title> -->
    <link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri();?>/assets/images/favicon.ico" />
	<?php wp_head(); ?>
  </head>
  <body>

<!-- Menu bar -->
<?php include get_template_directory() .'/includes/menu.php';?>